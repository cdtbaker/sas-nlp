package org.apache.commons.math3.stat.data;
/** 
 * @version $Id: LewTest.java 1244107 2012-02-14 16:17:55Z erans $
 */
public class LewTest extends CertifiedDataAbstractTest {
  @Override protected String getResourceName(){
    return "org/apache/commons/math3/stat/data/Lew.txt";
  }
}
