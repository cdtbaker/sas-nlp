package org.apache.commons.math3.stat.data;
/** 
 * @version $Id: LotteryTest.java 1244107 2012-02-14 16:17:55Z erans $
 */
public class LotteryTest extends CertifiedDataAbstractTest {
  @Override protected String getResourceName(){
    return "org/apache/commons/math3/stat/data/Lottery.txt";
  }
}
